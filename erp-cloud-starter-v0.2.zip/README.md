# ERP Cloud Injetoras — Starter v0.2 (100% Nuvem)

Este pacote é para **leigos**: siga o passo a passo abaixo. Você NÃO precisa instalar nada no seu computador se não quiser — dá para fazer tudo pelo navegador.

---

## 0) O que você vai criar
- App web (Next.js) hospedado na **Vercel**.
- Banco de dados **PostgreSQL** gerenciado no **Supabase**.
- PWA do Operador (instalável no tablet).
- API HTTPS para o ESP32 enviar eventos de produção.

---

## 1) Crie contas (grátis)
1. **GitHub** (se não tiver): https://github.com – clique **Sign up**.
2. **Vercel**: https://vercel.com – clique **Continue with GitHub** e autorize.
3. **Supabase**: https://supabase.com – **Sign in** (pode usar GitHub).

---

## 2) Envie este projeto para o seu GitHub
1. Baixe este ZIP e descompacte.
2. No GitHub, clique **New repository** → nome: `erp-cloud` → **Create repository**.
3. Envie os arquivos do projeto (arraste-e-solte pela interface Web do GitHub ou use Git se souber).

> Dica: Se preferir, você pode criar o repositório vazio e fazer **Upload files** direto no GitHub.

---

## 3) Crie o banco no Supabase
1. No painel do **Supabase**, clique **New project**.
2. Escolha um nome e senha (guarde a senha).
3. Com o projeto criado, vá em **SQL Editor**.
4. Copie o conteúdo do arquivo `supabase_schema.sql` (desta pasta) e **cole** no SQL Editor.
5. Clique **Run** para criar as tabelas e views.

Guarde três dados do Supabase (em **Project Settings → API**):
- `Project URL`
- `anon key` (NEXT_PUBLIC_SUPABASE_ANON_KEY)
- `service_role key` (SUPABASE_SERVICE_ROLE)

---

## 4) Deploy do app na Vercel
1. Na **Vercel**, clique **Add New → Project**.
2. Selecione o repositório `erp-cloud` do GitHub.
3. Em **Environment Variables**, adicione:
   - `NEXT_PUBLIC_SUPABASE_URL` = (Project URL do Supabase)
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` = (anon key)
   - `SUPABASE_SERVICE_ROLE` = (service_role key)
   - `INGEST_SHARED_SECRET` = (uma senha simples, ex.: `minha-senha`)
4. Clique **Deploy** e aguarde. Ao final, você terá um domínio do tipo: `https://seuapp.vercel.app`.

---

## 5) Cadastros mínimos
1. Acesse `https://SEU_DOMINIO.vercel.app/admin`
2. Cadastre pelo menos:
   - Uma máquina (ex.: code = INJ-01).
   - Um produto (ex.: code = P-100).
   - Uma OP (ex.: number = OP-0001).

---

## 6) Teste o operador (PWA)
1. No tablet/celular, abra `https://SEU_DOMINIO.vercel.app/operador`.
2. Menu do navegador → **Adicionar à tela inicial** (isso instala o PWA).
3. Na tela: selecione `INJ-01` e `OP-0001` → toque **Peça OK** / **Refugo**.
4. Os eventos vão para o banco (ver **SQL Editor** → consulte `machine_events`).

---

## 7) Teste o endpoint com ESP32 (opcional agora)
- Abra `esp32_https_example.ino` e edite:
  - `endpoint`: `https://SEU_DOMINIO.vercel.app/api/events`
  - Cabeçalho `x-shared-secret`: o mesmo valor do `INGEST_SHARED_SECRET` que você colocou na Vercel.
- Grave o sketch no ESP32 e monitore o Serial para ver `POST 200`.

---

## 8) Rotas úteis
- `/operador` — PWA do operador
- `/admin` — cadastros simples
- `/api/events` — ingestão de eventos
- `/api/oee` — dados OEE das últimas horas
- `/api/work-orders` — listar/criar OPs

---

## 9) Próximos passos (quando quiser evoluir)
- Cronograma (Gantt) de OPs por máquina/turno.
- Estoque/MRP (mínimos, reserva por OP, consumo por ciclo).
- Financeiro/Contábil JP (インボイス, 消費税, export CSV/API).
- Dashboards (Metabase Cloud).

> Qualquer dúvida, fale comigo que eu ajusto e adiciono as telas no seu app.

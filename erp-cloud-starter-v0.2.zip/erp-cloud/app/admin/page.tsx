'use client'
import { useEffect, useState } from 'react'

async function api(path: string, init?: RequestInit){
  const res = await fetch(path, init)
  if(!res.ok) throw new Error(await res.text())
  return res.json()
}

export default function Admin(){
  const [machines, setMachines] = useState<any[]>([])
  const [products, setProducts] = useState<any[]>([])
  const [woList, setWoList] = useState<any[]>([])

  const [mCode, setMCode] = useState('INJ-01')
  const [mName, setMName] = useState('Injetora 01')
  const [pCode, setPCode] = useState('P-100')
  const [pName, setPName] = useState('Peça 100')
  const [woNumber, setWoNumber] = useState('OP-0001')
  const [woTarget, setWoTarget] = useState(1000)

  async function load(){
    const [m,p,w] = await Promise.all([
      api('/api/admin?type=machines'),
      api('/api/admin?type=products'),
      api('/api/work-orders')
    ])
    setMachines(m); setProducts(p); setWoList(w)
  }
  useEffect(()=>{ load() }, [])

  async function addMachine(){
    await api('/api/admin', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({type:'machine', code:mCode, name:mName}) })
    await load()
  }
  async function addProduct(){
    await api('/api/admin', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({type:'product', code:pCode, name:pName}) })
    await load()
  }
  async function addWO(){
    await api('/api/work-orders', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({number:woNumber, product_id: products[0]?.id || 1, target_qty: woTarget}) })
    await load()
  }

  return (
    <div style={{fontFamily:'system-ui', padding:16}}>
      <h1>Admin</h1>

      <h2>Máquinas</h2>
      <input placeholder="code" value={mCode} onChange={e=>setMCode(e.target.value)} />
      <input placeholder="name" value={mName} onChange={e=>setMName(e.target.value)} />
      <button onClick={addMachine}>Adicionar</button>
      <pre>{JSON.stringify(machines, null, 2)}</pre>

      <h2>Produtos</h2>
      <input placeholder="code" value={pCode} onChange={e=>setPCode(e.target.value)} />
      <input placeholder="name" value={pName} onChange={e=>setPName(e.target.value)} />
      <button onClick={addProduct}>Adicionar</button>
      <pre>{JSON.stringify(products, null, 2)}</pre>

      <h2>Ordens de Produção</h2>
      <input placeholder="number" value={woNumber} onChange={e=>setWoNumber(e.target.value)} />
      <input placeholder="target qty" type="number" value={woTarget} onChange={e=>setWoTarget(parseInt(e.target.value||'0'))} />
      <button onClick={addWO}>Criar OP</button>
      <pre>{JSON.stringify(woList, null, 2)}</pre>
    </div>
  )
}

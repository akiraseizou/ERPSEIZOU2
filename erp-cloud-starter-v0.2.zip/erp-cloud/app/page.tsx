export default function Home(){
  return (
    <main style={{fontFamily:'system-ui', padding:16}}>
      <h1>ERP Cloud — Injetoras</h1>
      <p>Bem-vindo. Use as rotas:</p>
      <ul>
        <li><a href="/operador">/operador</a> — PWA do operador</li>
        <li><a href="/admin">/admin</a> — cadastros simples</li>
      </ul>
    </main>
  )
}

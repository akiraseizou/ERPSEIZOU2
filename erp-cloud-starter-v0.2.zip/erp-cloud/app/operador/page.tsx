'use client'
import { useEffect, useState } from 'react'

export default function Operador(){
  const [machineCode, setMachineCode] = useState('INJ-01')
  const [wo, setWo] = useState('OP-0001')
  const [ok, setOk] = useState(0)
  const [scrap, setScrap] = useState(0)

  async function post(type:'cycle_ok'|'scrap'|'start'|'stop'|'setup'){
    try{
      await fetch('/api/events',{
        method:'POST',
        headers:{
          'Content-Type':'application/json',
          'x-shared-secret': (process.env.NEXT_PUBLIC_SHARED_SECRET as string) ?? ''
        },
        body: JSON.stringify({ machine_code: machineCode, work_order_number: wo, type })
      })
      if(type==='cycle_ok') setOk(v=>v+1)
      if(type==='scrap') setScrap(v=>v+1)
    }catch(e){
      const queue = JSON.parse(localStorage.getItem('evt_queue')||'[]')
      queue.push({ machineCode, wo, type, ts: Date.now() })
      localStorage.setItem('evt_queue', JSON.stringify(queue))
    }
  }

  useEffect(()=>{
    const resend = async ()=>{
      const q = JSON.parse(localStorage.getItem('evt_queue')||'[]')
      if(q.length){
        for(const it of q){
          await fetch('/api/events',{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify({ machine_code: it.machineCode, work_order_number: it.wo, type: it.type })
          })
        }
        localStorage.removeItem('evt_queue')
      }
    }
    window.addEventListener('online', resend)
    resend()
    return ()=>window.removeEventListener('online', resend)
  },[])

  return (
    <div style={{fontFamily:'system-ui', padding:16}}>
      <h1>Operador</h1>
      <label>Máquina</label>
      <input value={machineCode} onChange={e=>setMachineCode(e.target.value)} />
      <label>OP</label>
      <input value={wo} onChange={e=>setWo(e.target.value)} />
      <div style={{display:'flex', gap:8, marginTop:12}}>
        <button onClick={()=>post('start')}>Start</button>
        <button onClick={()=>post('cycle_ok')}>Peça OK</button>
        <button onClick={()=>post('scrap')}>Refugo</button>
        <button onClick={()=>post('stop')}>Parada</button>
      </div>
      <div style={{marginTop:16}}>
        <strong>OK:</strong> {ok} &nbsp; <strong>Refugo:</strong> {scrap}
      </div>
    </div>
  )
}

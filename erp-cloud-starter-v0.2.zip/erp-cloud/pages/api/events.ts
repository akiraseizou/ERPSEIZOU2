import type { NextApiRequest, NextApiResponse } from 'next'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE!)

export default async function handler(req: NextApiRequest, res: NextApiResponse){
  if(req.method !== 'POST') return res.status(405).json({error:'Method Not Allowed'})
  const secret = req.headers['x-shared-secret'] as string | undefined
  if(process.env.INGEST_SHARED_SECRET && secret !== process.env.INGEST_SHARED_SECRET){
    return res.status(401).json({error:'unauthorized'})
  }
  const { machine_code, work_order_number, type, payload } = req.body || {}
  if(!machine_code || !type) return res.status(400).json({error:'missing fields'})

  const m = await supabase.from('machines').select('id').eq('code', machine_code).maybeSingle()
  if(!m.data) return res.status(404).json({error:'machine not found'})

  let wo_id: number | null = null
  if(work_order_number){
    const w = await supabase.from('work_orders').select('id').eq('number', work_order_number).maybeSingle()
    if(w.data) wo_id = (w.data as any).id
  }

  const ins = await supabase.from('machine_events').insert({ machine_id: (m.data as any).id, work_order_id: wo_id, type, payload: payload || null }).select('id').maybeSingle()
  if(ins.error) return res.status(500).json({error: ins.error.message})
  return res.status(200).json({id: ins.data?.id})
}

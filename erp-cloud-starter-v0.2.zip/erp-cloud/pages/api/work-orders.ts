import type { NextApiRequest, NextApiResponse } from 'next'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE!)

export default async function handler(req: NextApiRequest, res: NextApiResponse){
  if(req.method==='GET'){
    const { data, error } = await supabase.from('work_orders').select('*').order('id', { ascending:false }).limit(200)
    if(error) return res.status(500).json({error: error.message})
    return res.status(200).json(data)
  }
  if(req.method==='POST'){
    const { number, product_id, target_qty, start_planned, end_planned, priority } = req.body
    const { data, error } = await supabase.from('work_orders').insert({ number, product_id, target_qty, start_planned, end_planned, priority }).select('id').maybeSingle()
    if(error) return res.status(500).json({error: error.message})
    return res.status(200).json({id: data?.id})
  }
  return res.status(405).json({error:'Method Not Allowed'})
}

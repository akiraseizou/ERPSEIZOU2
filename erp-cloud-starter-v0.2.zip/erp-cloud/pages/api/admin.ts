import type { NextApiRequest, NextApiResponse } from 'next'
import { createClient } from '@supabase/supabase-js'
const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE!)

export default async function handler(req: NextApiRequest, res: NextApiResponse){
  if(req.method==='GET'){
    const type = req.query.type
    if(type==='machines'){
      const { data, error } = await supabase.from('machines').select('*').order('id', {ascending:true})
      if(error) return res.status(500).json({error: error.message})
      return res.status(200).json(data)
    }
    if(type==='products'){
      const { data, error } = await supabase.from('products').select('*').order('id', {ascending:true})
      if(error) return res.status(500).json({error: error.message})
      return res.status(200).json(data)
    }
    return res.status(400).json({error:'invalid type'})
  }
  if(req.method==='POST'){
    const body = req.body || {}
    if(body.type==='machine'){
      const { data, error } = await supabase.from('machines').insert({code: body.code, name: body.name}).select('id').maybeSingle()
      if(error) return res.status(500).json({error: error.message})
      return res.status(200).json({id: data?.id})
    }
    if(body.type==='product'){
      const { data, error } = await supabase.from('products').insert({code: body.code, name: body.name}).select('id').maybeSingle()
      if(error) return res.status(500).json({error: error.message})
      return res.status(200).json({id: data?.id})
    }
    return res.status(400).json({error:'invalid body'})
  }
  return res.status(405).json({error:'Method Not Allowed'})
}
